import pandas as pd
import plotly.graph_objects as go

# Read the CSV file.
df = pd.read_csv('USDA_PDP_AnalyticalResults_edit.csv', low_memory=False)

# Prompt the user to input the pesticide name, case sensitive.
pesticide = input("Enter the Pesticide name (case sensitive): ")

# NOTABLE PESTICIDE NAMES: Atrazine, Chlorpyrifos, Glyphosate, Imidacloprid, '2,4-D', Clothianidin, Thiamethoxam, Malathion, Diazinon, Atrazine, Dicamba.

# Filters the dataframe for the selected pesticide.
data = df[df['Pesticide Name'] == pesticide][['State', 'Concentration']].copy()

# Makes sure concentration values are numeric.
data['Concentration'] = pd.to_numeric(data['Concentration'], errors='coerce')

# Drops the rows with missing concentration values, not needed for the selected file but worth keeping.
data = data.dropna(subset=['Concentration'])

# Group by state and keep the top value per state, this ensures that only the top concentrations are selected per state.
data = data.groupby('State', as_index=False).max()

# Creates the color-coded map. More details in comments.
fig = go.Figure(data=go.Choropleth(
    locations = data['State'], # plugs in 'State' as location
    z = data['Concentration'], # plugs in 'Concentration' as numerical variable
    locationmode = 'USA-states', # creates the United States as a map
    colorscale = 'Viridis', # cool color scale, change if you want another cool color
    marker_line_color = 'white', # white outline for the states
    colorbar_title = pesticide + ' Concentration' # names the gradient legend
))

# Updates the layout for better visualization.
fig.update_layout(
    title_text = pesticide + ' Concentration by State',
    geo = dict(
        lakecolor = 'rgb(255, 255, 255)',
        projection_type = 'albers usa'
    )
)

# Actually shows the map. Remove this if you want to make the previous code completely useless.
fig.show()
